package TestCases;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.testng.annotations.Test;

import io.restassured.response.Response;

import static io.restassured.RestAssured.given;


public class ListofMethods {
	
	@Test(description = "To demonstarate the get method")
	public void getMethodExample() {
		
		Response res=given().when().get("https://reqres.in/api/users/2");
		System.out.println(res.asString());
		
		//get JSON parameter with values
		System.out.println(res.path("data.email").toString());
		System.out.println(res.path("support.url").toString());
	}
	
	@Test(description = "Verify status code")
	public void getMethodExample2() {
		
		Response res=given().when().get("https://reqres.in/api/unknown");
		System.out.println(res.asString());
		assertEquals(res.getStatusCode(), 200);
	}

	@Test(description = "To demonstrate post method")
	public void PostMethod() {
     	Response res=given().header("Content-Type", "application/json").body("{\r\n" + 
     			"   \"name\": \"dharmesh\",\r\n" + 
     			"   \"id\": \"176\",\r\n" + 
     			"   \"createdAt\": \"2022-02-17T05:24:02.914Z\"\r\n" + 
     			"}").post("https://reqres.in/api/users");
		System.out.println(res.asString());
	}
	
	@Test(description = "To demonstrate post method by dynamic JSON")
	public void PostMethodByJson() throws IOException {	
		FileInputStream file = new FileInputStream(new File(System.getProperty("user.dir") + "\\data\\POST.json"));
     	Response res=given().header("Content-Type", "application/json").body(IOUtils.toString(file)).post("https://reqres.in/api/users");
		System.out.println(res.asString());
	}
	
	@Test(description = "To demonstrate put method by dynamic JSON")
	public void PutMethodByJson() throws IOException {	
		FileInputStream file = new FileInputStream(new File(System.getProperty("user.dir") + "\\data\\PUT.json"));
     	Response res=given().header("Content-Type", "application/json").body(IOUtils.toString(file)).post("https://reqres.in/api/users/2");
		System.out.println(res.asString());
	}
	
	@Test(description = "To demonstrate delete method by dynamic JSON")
	public void DeleteMethodByJson() throws IOException {
		Response res=given().when().delete("https://reqres.in/api/users/2");
		assertEquals(res.getStatusCode(), 204);
	}
}
